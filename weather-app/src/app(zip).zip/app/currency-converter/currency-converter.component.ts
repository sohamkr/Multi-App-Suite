import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {ReactiveFormsModule} from '@angular/forms';
import {CurrencyService} from '../services/currency/currency.service'
import { CommonModule } from '@angular/common';
import {CurrencySelectorComponent} from './children_components/currency-selector/currency-selector.component';


@Component({
  selector: 'app-currency-converter',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CurrencySelectorComponent],
  templateUrl: './currency-converter.component.html',
  styleUrl: './currency-converter.component.css'


})
export class CurrencyConverterComponent {
  public currency:any = '';
  public errorMessage:any = '';
  currencyConverter:FormGroup ;
  public currencies: any = [];

  constructor(private fb: FormBuilder, public _cs: CurrencyService) { 
    this.currencyConverter = this.fb.group({ 
    amount: ['100', Validators.required],
    from: ['dollar', Validators.required],
    to: ['rupee', Validators.required]
  }); }

  ngOnInit(): void {
    this._cs.getCurrenciesObservable().subscribe(
      (data) => {
        this.currencies = data;
        console.log(data);
        
      },
      (error) => {
        console.log(error);
      }
    );
  }
  

}

