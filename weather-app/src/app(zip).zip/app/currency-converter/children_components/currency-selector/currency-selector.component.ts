import { Component } from '@angular/core';
import {CurrencyService} from '../../../services/currency/currency.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Input } from '@angular/core';
@Component({
  selector: 'app-currency-selector',
  imports: [FormsModule, CommonModule],
  templateUrl: './currency-selector.component.html',
  styleUrl: './currency-selector.css'
})

export class CurrencySelectorComponent {

  public findCurrency: any = '';
  public currencies:any;
  public elementCurrenciesList: any;
  public isEdited = true; 
  public ignoreFocusOut = false;
  @Input() selectorId:any;
 

  constructor( public _cs: CurrencyService) { 
       }
  
       ngOnInit(): void {
        console.log(this.selectorId);
        this._cs.getCurrenciesObservable().subscribe(
          (data) => {
            this.currencies = data;
            
            
          },
          (error) => {
            console.log(error);
          }
        );
      }
      ngAfterViewInit(): void{
        this.elementCurrenciesList = document.getElementById('currenciesList ' + this.selectorId);
        // this.selectCurrencyOnStart();
        
      }
      
  
  HideDropdown(){
    this.elementCurrenciesList.className = "dropdown-menu scrollable-menu";
    this.isEdited = true;
    console.log("hide dropdown");
    alert("high dropdown:");
  }

  showDropdown(){
    this.isEdited = false;
    this.elementCurrenciesList.className = "dropdown-menu scrollable-menu show";
  }

  

  focusout() {
    console.log("focus out");
  }

  focusOutInput() {
    console.log("focusOutInput");
  }

  valueFinding(){
    console.log("value finding");
  }

  selectCurrency(){
    console.log("select currency");

  }

  selectCurrencyFunc(currency:any){
    console.log("currency");
  }

  dropClick(){
    console.log("dropclick");
  }



  

}
